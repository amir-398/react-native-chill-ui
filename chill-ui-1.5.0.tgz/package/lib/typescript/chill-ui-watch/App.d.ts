import React from 'react';
import './global.css';
export default function App(): React.JSX.Element;
//# sourceMappingURL=App.d.ts.map