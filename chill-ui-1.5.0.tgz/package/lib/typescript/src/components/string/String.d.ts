import React from 'react';
import type { StringProps } from '../../types';
export default function String(props: StringProps): React.JSX.Element;
//# sourceMappingURL=String.d.ts.map