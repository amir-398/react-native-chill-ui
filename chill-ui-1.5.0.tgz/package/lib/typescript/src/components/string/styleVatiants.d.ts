export declare const textSizeVr: import("tailwind-variants").TVReturnType<{
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        '4xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, "text-lg", {
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        '4xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, import("tailwind-variants").TVReturnType<{
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        '4xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, "text-lg", unknown, unknown, undefined>>;
export declare const textFontVr: import("tailwind-variants").TVReturnType<{
    font: {
        primary: string;
        secondary: string;
        tertiary: string;
    };
    weight: {
        bold: string;
        light: string;
        medium: string;
        regular: string;
        semiBold: string;
    };
}, undefined, "font-primary", {
    font: {
        primary: string;
        secondary: string;
        tertiary: string;
    };
    weight: {
        bold: string;
        light: string;
        medium: string;
        regular: string;
        semiBold: string;
    };
}, undefined, import("tailwind-variants").TVReturnType<{
    font: {
        primary: string;
        secondary: string;
        tertiary: string;
    };
    weight: {
        bold: string;
        light: string;
        medium: string;
        regular: string;
        semiBold: string;
    };
}, undefined, "font-primary", unknown, unknown, undefined>>;
export declare const textColorVr: import("tailwind-variants").TVReturnType<{
    color: {
        primary: string;
        secondary: string;
        error: string;
        info: string;
        danger: string;
        success: string;
        warning: string;
        tertiary: string;
        white: string;
        dark: string;
        light: string;
    };
}, undefined, "text-white", {
    color: {
        primary: string;
        secondary: string;
        error: string;
        info: string;
        danger: string;
        success: string;
        warning: string;
        tertiary: string;
        white: string;
        dark: string;
        light: string;
    };
}, undefined, import("tailwind-variants").TVReturnType<{
    color: {
        primary: string;
        secondary: string;
        error: string;
        info: string;
        danger: string;
        success: string;
        warning: string;
        tertiary: string;
        white: string;
        dark: string;
        light: string;
    };
}, undefined, "text-white", unknown, unknown, undefined>>;
export declare const textPositionVr: import("tailwind-variants").TVReturnType<{
    position: {
        center: string;
        left: string;
        right: string;
    };
}, undefined, "text-left", {
    position: {
        center: string;
        left: string;
        right: string;
    };
}, undefined, import("tailwind-variants").TVReturnType<{
    position: {
        center: string;
        left: string;
        right: string;
    };
}, undefined, "text-left", unknown, unknown, undefined>>;
export declare const textVariantVr: import("tailwind-variants").TVReturnType<{
    variant: {
        'title-1': string;
        'title-2': string;
        'title-3': string;
        'title-4': string;
        'subtitle-1': string;
        'subtitle-2': string;
        'subtitle-3': string;
        'subtitle-4': string;
        'body-xl': string;
        'body-1': string;
        'body-2': string;
        'body-3': string;
        'body-4': string;
    };
}, undefined, "body-1", {
    variant: {
        'title-1': string;
        'title-2': string;
        'title-3': string;
        'title-4': string;
        'subtitle-1': string;
        'subtitle-2': string;
        'subtitle-3': string;
        'subtitle-4': string;
        'body-xl': string;
        'body-1': string;
        'body-2': string;
        'body-3': string;
        'body-4': string;
    };
}, undefined, import("tailwind-variants").TVReturnType<{
    variant: {
        'title-1': string;
        'title-2': string;
        'title-3': string;
        'title-4': string;
        'subtitle-1': string;
        'subtitle-2': string;
        'subtitle-3': string;
        'subtitle-4': string;
        'body-xl': string;
        'body-1': string;
        'body-2': string;
        'body-3': string;
        'body-4': string;
    };
}, undefined, "body-1", unknown, unknown, undefined>>;
//# sourceMappingURL=styleVatiants.d.ts.map