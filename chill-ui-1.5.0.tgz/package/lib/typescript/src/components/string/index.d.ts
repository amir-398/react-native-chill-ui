export { default } from './String';
//# sourceMappingURL=index.d.ts.map