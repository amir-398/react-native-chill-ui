export { default } from './toggle';
//# sourceMappingURL=index.d.ts.map