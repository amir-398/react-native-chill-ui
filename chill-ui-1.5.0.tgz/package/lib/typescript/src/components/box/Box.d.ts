import React from 'react';
import type { ViewProps } from 'react-native';
export default function Box(props: ViewProps): React.JSX.Element;
//# sourceMappingURL=Box.d.ts.map