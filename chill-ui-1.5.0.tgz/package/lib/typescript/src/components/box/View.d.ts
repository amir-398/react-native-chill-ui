import React from 'react';
import type { ViewProps as NativeViewProps } from 'react-native';
import type { AnimatedViewProps } from '../../types';
export declare const NativeView: any;
export declare function View(props: NativeViewProps): React.JSX.Element;
export declare function AnimatedView(props: AnimatedViewProps): React.JSX.Element;
//# sourceMappingURL=View.d.ts.map