import React from 'react';
import type { AnimatedViewProps } from '../../types';
export default function AnimatedBox(props: AnimatedViewProps): React.JSX.Element;
//# sourceMappingURL=AnimatedBox.d.ts.map