export { default } from './buttonIcon';
//# sourceMappingURL=index.d.ts.map