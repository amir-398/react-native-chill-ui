import React from 'react';
import type { ButtonIconProps } from '../../types';
export default function ButtonIcon(props: ButtonIconProps): React.JSX.Element;
//# sourceMappingURL=buttonIcon.d.ts.map