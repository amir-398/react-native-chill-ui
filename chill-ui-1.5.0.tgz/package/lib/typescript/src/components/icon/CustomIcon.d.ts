import React from 'react';
import type { SvgProps } from 'react-native-svg';
import { type TIcons } from '../../constants/ICONS';
export type IconProps = {
    name: keyof TIcons;
    color?: string;
} & SvgProps;
export default function CustomIcon({ className, color, name }: IconProps): React.JSX.Element;
//# sourceMappingURL=CustomIcon.d.ts.map