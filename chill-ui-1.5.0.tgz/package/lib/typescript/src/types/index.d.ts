/// <reference types="react" />
import type { VariantProps } from 'tailwind-variants';
import type { TextProps, ViewProps } from 'react-native';
import type { AnimatedProps } from 'react-native-reanimated';
import type { textColorVr, textFontVr, textPositionVr, textSizeVr, textVariantVr } from '../components/string/styleVatiants';
import type { TIcons } from '../constants/ICONS';
import type { IconSizeVr, paddingVr } from '../components/icon/Icon';
export interface StringProps extends TextProps {
    className?: string;
    onPress?: () => void;
    useFastText?: boolean;
    numberOfLines?: number;
    children?: string | React.ReactNode;
    size?: VariantProps<typeof textSizeVr>['size'];
    variant?: VariantProps<typeof textVariantVr>['variant'];
    position?: VariantProps<typeof textPositionVr>['position'];
    color?: VariantProps<typeof textColorVr>['color'];
    font?: VariantProps<typeof textFontVr>['font'];
    weight?: VariantProps<typeof textFontVr>['weight'];
}
export type AnimatedViewProps = AnimatedProps<ViewProps>;
export type IconProps = {
    onPress?: () => void;
    wrapper?: boolean;
    color?: string;
    name: keyof TIcons;
    className?: string;
    size?: VariantProps<typeof IconSizeVr>['size'];
    padding?: VariantProps<typeof paddingVr>['size'];
};
export interface ButtonIconProps extends IconProps {
    testID: string;
    className?: string;
    onPress: () => void;
    isLoading?: boolean;
    isDisabled?: boolean;
    accessibilityLabel: string;
    iconColor: string;
    iconColorPressed: string;
}
//# sourceMappingURL=index.d.ts.map