import { tv } from 'tailwind-variants'

export const textSizeVr = tv({
  base: 'text-lg',
  variants: {
    size: {
      '2xl': 'text-3xl',
      '2xs': 'text-xs',
      '3xl': 'text-4xl',
      '4xl': 'text-5xl leading-snug',
      lg: 'text-xl',
      md: 'text-lg',
      sm: 'text-base',
      xl: 'text-2xl',
      xs: 'text-sm',
    },
  },
})

export const textFontVr = tv({
  base: 'font-primary',
  variants: {
    font: {
      primary: 'font-primary',
      secondary: 'font-secondary',
      tertiary: 'font-tertiary',
    },
    weight: {
      bold: 'font-bold',
      light: 'font-light',
      medium: 'font-medium',
      regular: 'font-regular',
      semiBold: 'font-semibold',
    },
  },
  compoundVariants: [
    {
      font: 'primary',
      weight: 'bold',
      className: 'font-primaryBold',
    },
    {
      font: 'primary',
      weight: 'light',
      className: 'font-primaryLight',
    },
    {
      font: 'primary',
      weight: 'medium',
      className: 'font-primaryMedium',
    },
    {
      font: 'primary',
      weight: 'regular',
      className: 'font-primary',
    },
    {
      font: 'primary',
      weight: 'semiBold',
      className: 'font-primarySemiBold',
    },
    {
      font: 'secondary',
      weight: 'bold',
      className: 'font-secondaryBold',
    },
    {
      font: 'secondary',
      weight: 'light',
      className: 'font-secondaryLight',
    },
    {
      font: 'secondary',
      weight: 'medium',
      className: 'font-secondaryMedium',
    },
    {
      font: 'secondary',
      weight: 'regular',
      className: 'font-secondary',
    },
    {
      font: 'secondary',
      weight: 'semiBold',
      className: 'font-secondarySemiBold',
    },
    {
      font: 'tertiary',
      weight: 'bold',
      className: 'font-tertiaryBold',
    },
    {
      font: 'tertiary',
      weight: 'light',
      className: 'font-tertiaryLight',
    },
    {
      font: 'tertiary',
      weight: 'medium',
      className: 'font-tertiaryMedium',
    },
    {
      font: 'tertiary',
      weight: 'regular',
      className: 'font-tertiary',
    },
    {
      font: 'tertiary',
      weight: 'semiBold',
      className: 'font-tertiarySemiBold',
    },
  ],
})

export const textColorVr = tv({
  base: 'text-white',
  variants: {
    color: {
      primary: 'text-primary',
      secondary: 'text-secondary',
      error: 'text-error',
      info: 'text-info',
      danger: 'text-danger',
      success: 'text-success',
      warning: 'text-warning',
      tertiary: 'text-tertiary',
      white: 'text-white',
      dark: 'text-black',
      light: 'text-light',
    },
  },
})

export const textPositionVr = tv({
  base: 'text-left',
  variants: {
    position: {
      center: 'text-center',
      left: 'text-left',
      right: 'text-right',
    },
  },
})

export const textVariantVr = tv({
  base: 'body-1',
  variants: {
    variant: {
      'title-1': 'text-4xl font-primaryBold',
      'title-2': 'text-2xl font-primaryBold',
      'title-3': 'text-xl font-primaryBold',
      'title-4': 'text-lg font-primaryBold',
      'subtitle-1': 'text-lg font-primaryBold',
      'subtitle-2': 'text-base font-primaryBold',
      'subtitle-3': 'text-sm font-primaryBold',
      'subtitle-4': 'text-xs font-primaryBold',
      'body-xl': 'text-xl font-primary',
      'body-1': 'text-lg font-primary',
      'body-2': 'text-base font-primary',
      'body-3': 'text-sm font-primary',
      'body-4': 'text-xs font-primary',
    },
  },
})
