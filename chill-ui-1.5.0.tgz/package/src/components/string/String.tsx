import React from 'react'
import cn from '../cn'
import type { StringProps } from '../../types'
import { Text as NativeText } from './Text'
import { textColorVr, textFontVr, textPositionVr, textSizeVr, textVariantVr } from './styleVatiants'

export default function String(props: StringProps) {
  const { children, className, font, position, size, variant, color, weight } = props

  const dynamicClasses = cn(
    'flex-shrink',
    textSizeVr({ size }),
    textFontVr({ font, weight }),
    textColorVr({ color }),
    textPositionVr({ position }),
    textVariantVr({ variant }),
    className,
  )

  return (
    <NativeText {...props} className={dynamicClasses}>
      {children}
    </NativeText>
  )
}
