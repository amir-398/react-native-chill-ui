export { default } from './Icon'
