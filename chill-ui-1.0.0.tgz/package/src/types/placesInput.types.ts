import type { addressComponentsTypes, PlaceInputSelectedValue } from './common.types';

import { StrictOmit } from './utils/StrictOmit.types';
import { AutocompleteDropdownProps } from './autocompleteDropdown.type';

/**
 * Place data structure returned by Google Places API
 * Contains detailed information about a selected place including address components,
 * coordinates, and formatted addresses.
 *
 * @example
 * ```tsx
 * onSelect={(place: Place) => {
 *   console.log('Full address:', place.formattedAddress);
 *   console.log('Coordinates:', place.location);
 *   console.log('City:', place.addressComponents.find(c => c.types.includes('locality'))?.longText);
 * }}
 * ```
 */
export interface Place {
  /** Full formatted address (e.g., "123 Main St, New York, NY 10001, USA") */
  formattedAddress: string;
  /** Short formatted address (e.g., "123 Main St, New York") */
  shortFormattedAddress: string;
  /** Location coordinates for mapping */
  location: {
    /** Latitude coordinate */
    latitude: number;
    /** Longitude coordinate */
    longitude: number;
  };
  /** Postal address details (optional, may contain additional postal information) */
  postalAddress?: {
    /** Postal address components */
    [key: string]: any;
  };
  /** Address components with detailed information for each part of the address */
  addressComponents: {
    /** Language code for the component text */
    languageCode: string;
    /** Long text description (e.g., "New York" for locality) */
    longText: string;
    /** Short text description (e.g., "NY" for administrative_area_level_1) */
    shortText: string;
    /** Types of address component (e.g., ['locality', 'political']) */
    types: addressComponentsTypes[];
  }[];
}

/**
 * Places prediction data structure from autocomplete API
 * Represents a place suggestion returned by the Google Places autocomplete API.
 * This is the structure used in the dropdown list before a place is selected.
 *
 * @example
 * ```tsx
 * // In renderItem function
 * renderItem={(item: Places) => (
 *   <Text>{item.placePrediction.text.text}</Text>
 * )}
 * ```
 */
export interface Places {
  /** Place prediction information containing the suggestion details */
  placePrediction: {
    /** Unique place ID used to fetch detailed place information */
    placeId: string;
    /** Place details (may be undefined for predictions, populated after selection) */
    place?: Place;
    /** Text information for display in the dropdown */
    text: {
      /** Display text shown in the autocomplete dropdown */
      text: string;
    };
  };
}

/**
 * Places API response structure
 * Response format from the Google Places autocomplete API containing
 * an array of place suggestions.
 *
 * @example
 * ```tsx
 * // API response structure
 * {
 *   suggestions: [
 *     {
 *       placePrediction: {
 *         placeId: "ChIJ...",
 *         text: { text: "New York, NY, USA" }
 *       }
 *     }
 *   ]
 * }
 * ```
 */
export interface PlacesResponse {
  /** Array of place suggestions returned by the autocomplete API */
  suggestions: Places[];
}

/**
 * Props for the PlacesInput component
 *
 * @example
 * ```tsx
 * // Basic usage
 * <PlacesInput
 *   googleApiKey="your-api-key"
 *   onSelect={(place) => console.log(place)}
 * />
 *
 * // With country restriction and custom selection
 * <PlacesInput
 *   googleApiKey="your-api-key"
 *   queryCountries={['US', 'CA']}
 *   selectedValue="locality"
 *   onSelect={(place) => console.log(place)}
 *   requiredCharactersBeforeSearch={3}
 * />
 * ```
 */
export type PlacesInputProps = {
  /** External query value to control the input */
  query?: string;
  /** Google Places API key (required) */
  googleApiKey: string;
  /** Array of country codes to restrict search */
  queryCountries?: string[];
  /** Whether to clear the input after selection */
  clearQueryOnSelect?: boolean;
  /** Callback when a place is selected (with error handling) */
  onSelect?: (place: Place | Places['placePrediction']) => void;
  /** Debounce delay in milliseconds before triggering search */
  requiredTimeBeforeSearch?: number;
  /** Minimum number of characters before triggering search */
  requiredCharactersBeforeSearch?: number;
  /** Type of address component to display after selection */
  selectedValue?: PlaceInputSelectedValue;
} & StrictOmit<AutocompleteDropdownProps<Places>, 'dataSet' | 'valueField' | 'onSelectItem'>;
