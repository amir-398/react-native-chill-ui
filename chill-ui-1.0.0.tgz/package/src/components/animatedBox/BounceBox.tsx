import { Animated } from 'react-native';
import { useRef, useEffect, useCallback, useImperativeHandle, forwardRef } from 'react';

import type { BounceBoxProps, BounceBoxRef } from '../../types/animatedBox';

import cn from '../cn';
import styles from './AnimatedBox.style';
import { AnimatedView as AnimatedViewNative } from '../box/View';
import { isNativeWindInstalled } from '../../utils/nativewindDetector';
import { classNamePropsHandler } from '../../utils/classNameMissingError';

/**
 * BounceBox - Playful bounce animation component
 *
 * Creates an attention-grabbing bounce effect by animating vertical translation. Perfect for
 * notifications, call-to-action elements, or any content that needs to catch the user's eye.
 * Supports both single bounces and continuous bouncing patterns.
 *
 * @example
 * ```tsx
 * // Basic auto-bouncing notification
 * <BounceBox autoStart infiniteLoop bounceHeight={15} className="bg-red-500 p-4 rounded-full">
 *   <String className="text-white font-bold">New Message!</String>
 * </BounceBox>
 *
 * // Custom bounce timing and height
 * <BounceBox
 *   autoStart
 *   bounceHeight={30}
 *   bounceInterval={1500}
 *   infiniteLoop
 *   className="bg-orange-500 p-3 rounded-lg"
 * >
 *   <Icon name="bell" className="text-white" />
 * </BounceBox>
 *
 * // Manual bounce control with ref
 * const bounceRef = useRef<BounceBoxRefProps>(null);
 *
 * <BounceBox ref={bounceRef} bounceHeight={25} className="bg-green-500 p-4">
 *   <String className="text-white">Click to bounce!</String>
 * </BounceBox>
 * ```
 *
 * @param bounceHeight - Height of bounce in pixels (default: 20)
 * @param bounceInterval - Time between bounces in milliseconds (default: 2000)
 * @param autoStart - Automatically start animation when component mounts (default: false)
 * @param duration - Single bounce duration in milliseconds (default: 400)
 * @param infiniteLoop - Loop animation continuously (default: false)
 * @param onBounce - Callback function called on each bounce
 * @param className - CSS classes for NativeWind styling
 * @param style - Inline styles for traditional styling or style overrides
 * @param children - Content to be animated
 * @param ref - Ref for manual animation control (bounce, start, stop methods)
 * @returns Animated component with bouncing effect
 */
const BounceBox = forwardRef<BounceBoxRef, BounceBoxProps>((props, ref) => {
  const {
    autoStart = false,
    bounceHeight = 20,
    bounceInterval = 2000,
    children,
    className,
    duration = 400,
    infiniteLoop = false,
    onBounce,
    style,
    ...rest
  } = props;
  classNamePropsHandler(props, 'BounceBox');
  const bounceAnim = useRef(new Animated.Value(0)).current;
  const animationRef = useRef<Animated.CompositeAnimation | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const isRunningRef = useRef(false);

  const startBounce = useCallback(() => {
    animationRef.current?.stop();
    bounceAnim.setValue(0);

    const animation = Animated.sequence([
      Animated.timing(bounceAnim, {
        duration: duration / 2,
        toValue: 1,
        useNativeDriver: true,
      }),
      Animated.timing(bounceAnim, {
        duration: duration / 2,
        toValue: 0,
        useNativeDriver: true,
      }),
    ]);

    animationRef.current = animation;
    animation.start();
    onBounce?.();
  }, [bounceAnim, duration, onBounce]);

  const startAnimation = useCallback(() => {
    if (isRunningRef.current) return;

    isRunningRef.current = true;

    if (infiniteLoop) {
      intervalRef.current = setInterval(startBounce, bounceInterval);
      startBounce();
    } else {
      startBounce();
    }
  }, [infiniteLoop, bounceInterval, startBounce]);

  const stopAnimation = useCallback(() => {
    isRunningRef.current = false;
    animationRef.current?.stop();

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    bounceAnim.setValue(0);
  }, [bounceAnim]);

  useImperativeHandle(
    ref,
    () => ({
      bounce: startBounce,
      start: startAnimation,
      stop: stopAnimation,
    }),
    [startBounce, startAnimation, stopAnimation],
  );

  useEffect(() => {
    if (autoStart || infiniteLoop) {
      startAnimation();
    }

    return () => {
      stopAnimation();
    };
  }, [autoStart, infiniteLoop, startAnimation, stopAnimation]);

  if (isNativeWindInstalled()) {
    return (
      <AnimatedViewNative
        className={cn('overflow-hidden', className)}
        style={[
          {
            transform: [
              {
                translateY: bounceAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, -bounceHeight],
                }),
              },
            ],
          },
          style,
        ]}
        {...rest}
      >
        {children}
      </AnimatedViewNative>
    );
  }

  return (
    <AnimatedViewNative
      style={[
        styles.bounceContainer,
        {
          transform: [
            {
              translateY: bounceAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -bounceHeight],
              }),
            },
          ],
        },
        style,
      ]}
      {...rest}
    >
      {children}
    </AnimatedViewNative>
  );
});

BounceBox.displayName = 'BounceBox';

export default BounceBox;
