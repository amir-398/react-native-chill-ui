import type { AnimatedBoxProps } from '../../types/animatedBox';

import cn from '../cn';
import styles from './AnimatedBox.style';
import { AnimatedView as AnimatedViewNative } from '../box/View';
import { isNativeWindInstalled } from '../../utils/nativewindDetector';
import { classNamePropsHandler } from '../../utils/classNameMissingError';

/**
 * AnimatedBox - Base animated container component
 *
 * A flexible animated container that serves as the foundation for all other animated components.
 * Provides optimal performance using React Native's internal ViewNativeComponent and automatically
 * detects NativeWind availability for seamless styling compatibility.
 *
 * @example
 * ```tsx
 * // With NativeWind (Tailwind CSS)
 * <AnimatedBox className="bg-blue-500 p-4 rounded-lg shadow-lg">
 *   <String className="text-white">Base animated container</String>
 * </AnimatedBox>
 *
 * // Without NativeWind (traditional styles)
 * <AnimatedBox style={{ backgroundColor: 'blue', padding: 16, borderRadius: 8 }}>
 *   <String style={{ color: 'white' }}>Base animated container</String>
 * </AnimatedBox>
 *
 * // As foundation for custom animations
 * <Animated.View style={{ transform: [{ scale: scaleValue }] }}>
 *   <AnimatedBox className="bg-green-500">
 *     <String>Custom animated content</String>
 *   </AnimatedBox>
 * </Animated.View>
 * ```
 *
 * @param className - CSS classes for NativeWind styling
 * @param style - Inline styles for traditional styling or style overrides
 * @param children - Content to be rendered inside the animated container
 * @param props - All other View props are supported
 * @returns Optimized animated view component ready for custom animations
 */
export default function AnimatedBox(props: AnimatedBoxProps) {
  const { className, style, ...rest } = props;
  classNamePropsHandler(props, 'AnimatedBox');

  if (isNativeWindInstalled()) {
    return <AnimatedViewNative className={cn('overflow-hidden', className)} style={style} {...rest} />;
  }

  return <AnimatedViewNative style={[styles.baseAnimated, style]} {...props} />;
}
