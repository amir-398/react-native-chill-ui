export * from './avatar.types';
//# sourceMappingURL=index.d.ts.map