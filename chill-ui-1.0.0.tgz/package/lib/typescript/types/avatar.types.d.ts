import { StyleProp, ViewStyle } from 'react-native';
import type { SvVariantProps } from '../utils/styleSheetVariants';
import type { AvatarSv } from '../avatar/styles/Avatar.styles';
/**
 * Props for Avatar component
 *
 */
export type AvatarProps = SvVariantProps<typeof AvatarSv> & {
    /** Custom CSS classes */
    className?: string;
    /** Callback when avatar is pressed */
    onPress?: () => void;
    /** User data for avatar display */
    data: {
        /** User's first name */
        firstname?: string;
        /** User's last name */
        lastname?: string;
        /** User's profile image URL */
        image_url?: string;
    };
    /** Custom background color */
    color?: string;
    /** Props for the String component displaying initials */
    stringProps?: object;
    /** Component to use when avatar is pressable - default: 'Pressable' */
    as?: 'pressable' | 'touchable-opacity' | 'ripple-pressable';
    style?: StyleProp<ViewStyle>;
};
//# sourceMappingURL=avatar.types.d.ts.map