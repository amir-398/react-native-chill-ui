import type { ImageStyle, TextStyle, ViewStyle } from 'react-native';
type StringToBoolean<T> = T extends 'true' | 'false' ? boolean : T;
type Style = ViewStyle | TextStyle | ImageStyle;
export type SvVariantProps<Component extends (...args: any) => any> = Parameters<Component>[0];
type VariantShape = Record<string, Record<string, Style>>;
type CompoundVariant<V extends VariantShape> = {
    [Variant in keyof V]?: StringToBoolean<keyof V[Variant]> | undefined;
} & {
    style: Style;
};
type VariantSchema<V extends VariantShape> = {
    [Variant in keyof V]?: StringToBoolean<keyof V[Variant]> | undefined;
};
export type Config<K extends Style, V extends VariantShape = VariantShape> = {
    base?: K;
    variants?: V;
    defaultVariants?: VariantSchema<V>;
    compoundVariants?: CompoundVariant<V>[];
};
type Props<V> = V extends VariantShape ? VariantSchema<V> & {
    style?: Style;
} : never;
declare const sv: <K extends Style, V extends VariantShape = VariantShape>({ base, compoundVariants, defaultVariants, variants, }: Config<K, V>) => (_options?: Props<V> | undefined) => K;
export default sv;
//# sourceMappingURL=styleSheetVariants.d.ts.map