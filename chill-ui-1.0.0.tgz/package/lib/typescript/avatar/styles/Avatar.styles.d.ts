declare const AvatarSv: (_options?: ({
    size?: "md" | "2xl" | "2xs" | "3xl" | "lg" | "sm" | "xl" | "xs" | undefined;
    variant?: "circle" | "square" | undefined;
} & {
    style?: (import("react-native").ViewStyle | import("react-native").TextStyle | import("react-native").ImageStyle) | undefined;
}) | undefined) => {
    alignItems: "center";
    backgroundColor: string;
    justifyContent: "center";
    overflow: "hidden";
};
declare const styles: {
    image: {
        height: "100%";
        position: "absolute";
        width: "100%";
    };
};
export { AvatarSv, styles };
//# sourceMappingURL=Avatar.styles.d.ts.map