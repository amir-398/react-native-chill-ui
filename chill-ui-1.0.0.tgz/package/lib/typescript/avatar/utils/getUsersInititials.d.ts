/**
 * Get user initials from firstname and lastname
 *
 * @param data - User data containing firstname and lastname
 * @returns Formatted initials string
 *
 * @example
 * ```tsx
 * getUserInitials({ firstname: 'John', lastname: 'Doe' }) // Returns 'JD'
 * getUserInitials({ firstname: 'John' }) // Returns 'J'
 * getUserInitials({}) // Returns ''
 * ```
 */
declare function getUserInitials(data: {
    firstname?: string;
    lastname?: string;
}): string;
export default getUserInitials;
//# sourceMappingURL=getUsersInititials.d.ts.map