export { default as Avatar } from './components/Avatar';
//# sourceMappingURL=index.d.ts.map