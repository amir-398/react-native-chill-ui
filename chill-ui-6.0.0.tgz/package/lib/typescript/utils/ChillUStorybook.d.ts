export default function ChillUStorybook(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ChillUStorybook.d.ts.map