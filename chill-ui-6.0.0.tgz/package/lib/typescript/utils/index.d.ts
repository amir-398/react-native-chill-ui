import ChillUStorybook from './ChillUStorybook';
export default ChillUStorybook;
//# sourceMappingURL=index.d.ts.map