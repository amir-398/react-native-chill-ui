interface DevToolActionProps {
    children?: React.ReactNode;
    handleToggleStorybook: () => void;
}
export default function DevToolAction({ children, handleToggleStorybook }: DevToolActionProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DevToolAction.d.ts.map