import Toggle from './toggle';
export default Toggle;
//# sourceMappingURL=index.d.ts.map