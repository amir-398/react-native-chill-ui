export declare const SIZE_OPTIONS: string[];
interface ToggleProps {
    value: boolean;
    testID: string;
    className?: string;
    isLoading?: boolean;
    isDisabled?: boolean;
    onChange: (value: boolean) => void;
    size?: (typeof SIZE_OPTIONS)[number];
}
export default function Toggle(props: ToggleProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=toggle.d.ts.map