import ButtonIcon from './buttonIcon';
export default ButtonIcon;
//# sourceMappingURL=index.d.ts.map