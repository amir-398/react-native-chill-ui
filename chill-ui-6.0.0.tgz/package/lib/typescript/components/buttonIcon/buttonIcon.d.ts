import type { ButtonIconProps } from '../../types';
export default function ButtonIcon(props: ButtonIconProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=buttonIcon.d.ts.map