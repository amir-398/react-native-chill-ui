import type { SvgProps } from 'react-native-svg';
import { type TIcons } from '../../constants/ICONS';
export type IconProps = {
    name: keyof TIcons;
    color?: string;
} & SvgProps;
export default function CustomIcon({ className, color, name }: IconProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CustomIcon.d.ts.map