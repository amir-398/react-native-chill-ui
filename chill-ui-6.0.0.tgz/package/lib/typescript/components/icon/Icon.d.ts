import type { IconProps } from '../../types';
export declare const paddingVr: import("tailwind-variants").TVReturnType<{
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, "p-0", {
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, import("tailwind-variants").TVReturnType<{
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, "p-0", unknown, unknown, undefined>>;
export declare const IconSizeVr: import("tailwind-variants").TVReturnType<{
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, "w-6 h-6", {
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, import("tailwind-variants").TVReturnType<{
    size: {
        '2xl': string;
        '2xs': string;
        '3xl': string;
        lg: string;
        md: string;
        sm: string;
        xl: string;
        xs: string;
    };
}, undefined, "w-6 h-6", unknown, unknown, undefined>>;
export default function Icon({ className, color, name, onPress, size, wrapper }: IconProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Icon.d.ts.map