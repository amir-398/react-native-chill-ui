export { default as AnimatedBox } from './AnimatedBox';
export { default as Box } from './Box';
//# sourceMappingURL=index.d.ts.map