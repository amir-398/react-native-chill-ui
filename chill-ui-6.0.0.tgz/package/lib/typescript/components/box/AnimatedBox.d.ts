import type { AnimatedViewProps } from '../../types';
export default function AnimatedBox(props: AnimatedViewProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AnimatedBox.d.ts.map