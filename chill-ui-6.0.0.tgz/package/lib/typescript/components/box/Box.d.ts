import type { ViewProps } from 'react-native';
export default function Box(props: ViewProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Box.d.ts.map