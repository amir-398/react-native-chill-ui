import type { ViewProps as NativeViewProps } from 'react-native';
import type { AnimatedViewProps } from '../../types';
export declare const NativeView: any;
export declare function View(props: NativeViewProps): import("react/jsx-runtime").JSX.Element;
export declare function AnimatedView(props: AnimatedViewProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=View.d.ts.map