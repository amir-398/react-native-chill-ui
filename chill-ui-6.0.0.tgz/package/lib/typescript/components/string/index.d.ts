import String from './String';
export default String;
//# sourceMappingURL=index.d.ts.map