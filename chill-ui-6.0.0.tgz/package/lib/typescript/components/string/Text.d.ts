import type { ReactElement } from 'react';
import type { TextProps as NativeTextProps } from 'react-native';
import { Animated } from 'react-native';
export interface TextProps extends NativeTextProps {
    onPress?: () => void;
    useFastText?: boolean;
}
export type FastTextProps = Omit<TextProps, 'onPress' | 'onPressIn' | 'onPressOut' | 'onLongPress' | 'pressRetentionOffset'>;
export declare function FastText(props: FastTextProps): ReactElement;
export declare function Text(props: TextProps): import("react/jsx-runtime").JSX.Element;
export declare const AnimatedText: Animated.AnimatedComponent<typeof FastText>;
//# sourceMappingURL=Text.d.ts.map