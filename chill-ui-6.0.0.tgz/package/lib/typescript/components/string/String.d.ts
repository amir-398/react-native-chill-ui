import type { StringProps } from '../../types';
export default function String(props: StringProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=String.d.ts.map