import cn from './cn';
export default cn;
//# sourceMappingURL=index.d.ts.map