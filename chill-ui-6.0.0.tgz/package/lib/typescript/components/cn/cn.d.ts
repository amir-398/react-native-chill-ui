import { type ClassValue } from 'clsx';
declare const cn: (...inputs: ClassValue[]) => string;
export default cn;
//# sourceMappingURL=cn.d.ts.map