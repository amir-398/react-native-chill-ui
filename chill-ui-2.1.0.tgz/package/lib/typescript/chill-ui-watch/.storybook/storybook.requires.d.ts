/// <reference types="webpack-env" />
import { start } from '@storybook/react-native';
import '@storybook/addon-ondevice-controls/register';
import '@storybook/addon-ondevice-actions/register';
import '@storybook/addon-ondevice-notes/register';
declare const normalizedStories: {
    titlePrefix: string;
    directory: string;
    files: string;
    importPathMatcher: RegExp;
    req: __WebpackModuleApi.RequireContext;
}[];
declare global {
    var view: ReturnType<typeof start>;
    var STORIES: typeof normalizedStories;
}
export declare const view: ReturnType<typeof start>;
export {};
//# sourceMappingURL=storybook.requires.d.ts.map