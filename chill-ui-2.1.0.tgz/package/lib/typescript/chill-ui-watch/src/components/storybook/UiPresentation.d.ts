import { ReactNode } from 'react';
interface UiPresentationProps {
    className?: string;
    children: ReactNode;
}
export default function UiPresentation(props: UiPresentationProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=UiPresentation.d.ts.map