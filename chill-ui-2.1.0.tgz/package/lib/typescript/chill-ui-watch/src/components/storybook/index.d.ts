import UiPresentation from './UiPresentation';
export default UiPresentation;
//# sourceMappingURL=index.d.ts.map