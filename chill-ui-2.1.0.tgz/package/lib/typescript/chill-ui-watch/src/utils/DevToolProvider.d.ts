/// <reference types="react" />
export default function DevToolProvider({ children }: {
    children: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DevToolProvider.d.ts.map