interface DevToolActionProps {
    handleToggleStorybook: () => void;
}
export default function DevToolAction({ handleToggleStorybook }: DevToolActionProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DevToolAction.d.ts.map