import DevToolProvider from './DevToolProvider';
export default DevToolProvider;
//# sourceMappingURL=index.d.ts.map